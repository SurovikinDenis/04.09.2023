<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet"  href="css/style.css">
</head>
<body>
<header>
	<div class="logo">
		<p> logo </p>
		<div class="intro">
		<div class="text">
   	<h1> Intro </h1>
   	<p> Some introduction lines about the website or company</p>
      </div>
     </div>
	 <div class="link">
		<a href="#">Link1</a>
		<a href="#">Link2</a>
		<a href="#">Link3</a>
		<a href="#">Link4</a>
		<a href="#">Link5</a>
		<a href="#">Link6</a>
	</div>
   </div>
</header>
<main>
	<div class="top">
		<p>Services</p>
		<p>Services</p>
		<p>Services</p>
		<p>Recent Work</p>
		<p>Recent Work</p>
		<p>Recent Work</p>
	</div>
	<div class="bottom">
		<p>Twitter Feed</p>
	</div>
</main>
<footer>
	<div class="left">
		<a href="#">Link1</a>
		<a href="#">Link2</a>
		<a href="#">Link3</a>
		<a href="#">Link4</a>
		<a href="#">Link5</a>
		<a href="#">Link6</a>
	</div>
	<div class="right">
		<p>CopyNight Into</p>
	</div>
</footer>
</body>
</html>